package com.example.vethealth2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

class SendReg extends AsyncTask<String, Void, Bitmap> {

    private Exception exception;
    public HttpResponse myResponse=null;

    protected Bitmap doInBackground(String... urls) {
    	String id = urls[0];
    	try {        
		        HttpClient client = new DefaultHttpClient();
		        HttpPost post = new HttpPost();
		        post.setURI(new URI("http://192.168.43.160:8080/eoc_event/"+id+"?"));
		        File file = new File("ic_launcher-web.png");
		        InputStreamEntity reqEntity = new InputStreamEntity(new FileInputStream(file), -1);
	            reqEntity.setContentType("binary/octet-stream");
	            reqEntity.setChunked(true); // Send in multiple parts if needed
	            post.setEntity(reqEntity);
		        myResponse = client.execute(post);
    	}
		catch (Exception e) {
		        	e.printStackTrace();
        }
    	return null;
	}
    	

    protected void onPostExecute(HttpResponse feed) {
        // TODO: check this.exception 
        // TODO: do something with the feed
    }
}