package com.example.vethealth2;

import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.Toast;

public class TabsActivity extends Activity {

	private Spinner spinnerEvent;
	private String[] message = new String[5];
	private String myEvent;
	private static final int CAMERA_PIC_REQUEST = 1337;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tabs);
		initializeTabHost();
		initializeEventSpinner();
		Intent intent = this.getIntent();
		message[0] = intent.getStringExtra("id");
		message[1] = intent.getStringExtra("lastname");
		message[2] = intent.getStringExtra("firstname");
		message[3] = intent.getStringExtra("dob");
		message[4] = intent.getStringExtra("number");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tabs, menu);
		return true;
	}
	
	private void initializeTabHost() {
		TabHost tabs = (TabHost) findViewById(android.R.id.tabhost);
	    tabs.setup();

	    // My QR
	    TabHost.TabSpec myQRTab = tabs.newTabSpec("Mine");
	    myQRTab.setContent(R.id.myqrtab);
	    myQRTab.setIndicator("Mine");
	    tabs.addTab(myQRTab);
	    
	    // Capture QR
	    TabHost.TabSpec getQRTab = tabs.newTabSpec("Theirs");
	    getQRTab.setContent(R.id.getqrtab);
	    getQRTab.setIndicator("Theirs");
	    tabs.addTab(getQRTab);
	    
	    // Event List
	    TabHost.TabSpec eventListTab = tabs.newTabSpec("History");
	    eventListTab.setContent(R.id.myeventstab);
	    eventListTab.setIndicator("History");
	    tabs.addTab(eventListTab);
	}
	
	private void initializeEventSpinner() {
		spinnerEvent = (Spinner) findViewById(R.id.myqreventspinner);
		ArrayAdapter<CharSequence> adapterEvents = ArrayAdapter.createFromResource(this,
		        R.array.events, android.R.layout.simple_spinner_item);
		adapterEvents.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerEvent.setAdapter(adapterEvents);
	}
	
	public void addListenerOnButtonEvent() {
		spinnerEvent = (Spinner) findViewById(R.id.myqreventspinner);
		spinnerEvent.setOnItemSelectedListener(new SpinnerActivity());
		
		Button btnSubmitPatient = (Button) findViewById(R.id.myqrbutton);
		
		btnSubmitPatient.setOnClickListener(new OnClickListener() {
		  @Override
		  public void onClick(View v) {
			  if (String.valueOf(spinnerEvent.getSelectedItem()).equals("Office Visit")) {
				  myEvent = "OfficeVisit";
			  }
			  if (String.valueOf(spinnerEvent.getSelectedItem()).equals("ER Visit")) {
				  myEvent = "ERVisit";
			  }
			  if (String.valueOf(spinnerEvent.getSelectedItem()).equals("Outpatient Procedure")) {
				  myEvent = "OutpatientProcedure";
			  }
			  //Toast toast = Toast.makeText(getApplicationContext(), message[0], Toast.LENGTH_SHORT);
			  //toast.show();
		  }
	 
		});
	  }
	
    @Override 
	protected void onActivityResult(int requestCode, int resultCode, Intent data) { 
	 super.onActivityResult(requestCode, resultCode, data); 
	
	 if (RESULT_OK == resultCode) { 
	    ImageView iv = (ImageView) findViewById(R.id.getqrtab); 
	
	     // Decode it for real 
	    BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
	                   bmpFactoryOptions.inJustDecodeBounds = false; 
	
	    //imageFilePath image path which you pass with intent 
	    //Bitmap bmp = BitmapFactory.decodeFile(imageFilePath, bmpFactoryOptions); 
	    Bitmap bmp = (Bitmap) data.getExtras().get("data");
	    
	     // Display it 
	    iv.setImageBitmap(bmp); 
	    }    
	  }
    
    private static File getOutputMediaFile() {
        File mediaStorageDir = new File(
                Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "MyCameraApp");
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date());
        return new File(mediaStorageDir.getPath() + File.separator + "IMG_"
                + timeStamp + ".jpg");
    }
	
	public void myQR(View view) {
		Intent intent = new Intent(this, MyQRActivity.class);
		intent.putExtra("eventtype", myEvent);
		intent.putExtra("id", message[0]);
		addListenerOnButtonEvent();
		startActivity(intent);
	}
	
	public void takePicture(View view) {
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		Uri imageFileUri = Uri.fromFile(getOutputMediaFile());
		//String imageFilePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/picture.jpg";  
		//File imageFile = new File(imageFilePath); 
		//Uri imageFileUri = Uri.fromFile(imageFile); // convert path to Uri
		intent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri); 
	    startActivityForResult(intent, CAMERA_PIC_REQUEST);
	}
	
	public void sendPicture(View view) {
		SendReg newSend = new SendReg();
		String parameter = new String();
		parameter = message[0];
		try {
			newSend.execute(parameter).get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpResponse sent = newSend.myResponse;
		Toast toast = Toast.makeText(getApplicationContext(), "QR photo has been sent to http://192.168.43.160:8080", Toast.LENGTH_LONG);
		toast.show();
	}

}
