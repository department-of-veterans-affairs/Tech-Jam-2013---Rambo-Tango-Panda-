package com.example.vethealth2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Spinner spinnerMonthPatient, spinnerDayPatient, spinnerYearPatient;
	private Spinner spinnerMonthProvider, spinnerDayProvider, spinnerYearProvider;
	private EditText lastNamePatient, firstNamePatient;
	private EditText lastNameProvider, firstNameProvider;
	private EditText numberPatient, numberProvider;
	private String myIdentityPatient, myLastNamePatient, myFirstNamePatient, myDOBPatient, myNumberPatient;
	private String myIdentityProvider, myLastNameProvider, myFirstNameProvider, myDOBProvider, myNumberProvider;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initializeTabHost();
		initializePatientSpinner();
		initializeProviderSpinner();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void initializeTabHost() {
		TabHost tabs = (TabHost) findViewById(android.R.id.tabhost);
	    tabs.setup();

	    // Patient
	    TabHost.TabSpec patientTab = tabs.newTabSpec("Patient");
	    patientTab.setContent(R.id.Patient);
	    patientTab.setIndicator("Patient");
	    tabs.addTab(patientTab);
	    
	    
	    // Provider
	    TabHost.TabSpec providerTab = tabs.newTabSpec("Provider");
	    providerTab.setContent(R.id.Provider);
	    providerTab.setIndicator("Provider");
	    tabs.addTab(providerTab);
	    
	}
	
	private void initializePatientSpinner() {
		spinnerMonthPatient = (Spinner) findViewById(R.id.patientspinnermonth);
		ArrayAdapter<CharSequence> adapterMonthPatient = ArrayAdapter.createFromResource(this,
		        R.array.months, android.R.layout.simple_spinner_item);
		adapterMonthPatient.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerMonthPatient.setAdapter(adapterMonthPatient);
		
		spinnerDayPatient = (Spinner) findViewById(R.id.patientspinnerday);
		ArrayAdapter<CharSequence> adapterDayPatient = ArrayAdapter.createFromResource(this,
		        R.array.days, android.R.layout.simple_spinner_item);
		adapterDayPatient.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerDayPatient.setAdapter(adapterDayPatient);
		
		spinnerYearPatient = (Spinner) findViewById(R.id.patientspinneryear);
		ArrayAdapter<CharSequence> adapterYearPatient = ArrayAdapter.createFromResource(this,
		        R.array.years, android.R.layout.simple_spinner_item);
		adapterYearPatient.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerYearPatient.setAdapter(adapterYearPatient);
	}
	
	private void initializeProviderSpinner() {
		spinnerMonthProvider = (Spinner) findViewById(R.id.providerspinnermonth);
		ArrayAdapter<CharSequence> adapterMonthProvider = ArrayAdapter.createFromResource(this,
		        R.array.months, android.R.layout.simple_spinner_item);
		adapterMonthProvider.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerMonthProvider.setAdapter(adapterMonthProvider);
		
		spinnerDayProvider = (Spinner) findViewById(R.id.providerspinnerday);
		ArrayAdapter<CharSequence> adapterDayProvider = ArrayAdapter.createFromResource(this,
		        R.array.days, android.R.layout.simple_spinner_item);
		adapterDayProvider.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerDayProvider.setAdapter(adapterDayProvider);
		
		spinnerYearProvider = (Spinner) findViewById(R.id.providerspinneryear);
		ArrayAdapter<CharSequence> adapterYearProvider = ArrayAdapter.createFromResource(this,
		        R.array.years, android.R.layout.simple_spinner_item);
		adapterYearProvider.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerYearProvider.setAdapter(adapterYearProvider);
	}

	public void addListenerOnButtonPatient() {
		spinnerMonthPatient = (Spinner) findViewById(R.id.patientspinnermonth);
		spinnerMonthPatient.setOnItemSelectedListener(new SpinnerActivity());
		spinnerDayPatient = (Spinner) findViewById(R.id.patientspinnerday);
		spinnerDayPatient.setOnItemSelectedListener(new SpinnerActivity());
		spinnerYearPatient = (Spinner) findViewById(R.id.patientspinneryear);
		spinnerYearPatient.setOnItemSelectedListener(new SpinnerActivity());

		lastNamePatient = (EditText) findViewById(R.id.patientlastnameedit);
		myLastNamePatient = lastNamePatient.getText().toString();
		firstNamePatient = (EditText) findViewById(R.id.patientfirstnameedit);
		myFirstNamePatient = firstNamePatient.getText().toString();
		numberPatient = (EditText) findViewById(R.id.patientssnedit);
		myNumberPatient = numberPatient.getText().toString();

		Button btnSubmitPatient = (Button) findViewById(R.id.patientbutton);
		
		btnSubmitPatient.setOnClickListener(new OnClickListener() {
		  @Override
		  public void onClick(View v) {
			  myDOBPatient = String.valueOf(spinnerMonthPatient.getSelectedItem())+String.valueOf(spinnerDayPatient.getSelectedItem())+String.valueOf(spinnerYearPatient.getSelectedItem());
			  myIdentityPatient = "patient";
			  //Toast toast = Toast.makeText(getApplicationContext(), (CharSequence) myIdentityPatient+myDOBPatient+myLastNamePatient+myFirstNamePatient+myNumberPatient, Toast.LENGTH_SHORT);
			  //toast.show();
		  
		  }
	 
		});
	  }
	
	public void addListenerOnButtonProvider() {
		spinnerMonthProvider = (Spinner) findViewById(R.id.providerspinnermonth);
		spinnerMonthProvider.setOnItemSelectedListener(new SpinnerActivity());
		spinnerDayProvider = (Spinner) findViewById(R.id.providerspinnerday);
		spinnerDayProvider.setOnItemSelectedListener(new SpinnerActivity());
		spinnerYearProvider = (Spinner) findViewById(R.id.providerspinneryear);
		spinnerYearProvider.setOnItemSelectedListener(new SpinnerActivity());

		lastNameProvider = (EditText) findViewById(R.id.providerlastnameedit);
		myLastNameProvider = lastNameProvider.getText().toString();
		firstNameProvider = (EditText) findViewById(R.id.providerfirstnameedit);
		myFirstNameProvider = firstNameProvider.getText().toString();
		numberProvider = (EditText) findViewById(R.id.providerdeaedit);
		myNumberProvider = numberProvider.getText().toString();
		
		Button btnSubmitProvider = (Button) findViewById(R.id.providerbutton);
		
		btnSubmitProvider.setOnClickListener(new OnClickListener() {
		  @Override
		  public void onClick(View v) {
			  myDOBProvider = String.valueOf(spinnerMonthProvider.getSelectedItem())+String.valueOf(spinnerDayProvider.getSelectedItem())+String.valueOf(spinnerYearProvider.getSelectedItem());
			  myIdentityProvider = "provider";
			  //Toast toast = Toast.makeText(getApplicationContext(), (CharSequence) myIdentityProvider+myDOBProvider+myLastNameProvider+myFirstNameProvider+myNumberProvider, Toast.LENGTH_SHORT);
			  //toast.show();
			  
		  }
	 
		});
	  }
	
	public void sendMessagePatient(View view) {
		addListenerOnButtonPatient();
		Intent intent = new Intent(this, TabsActivity.class);
		intent.putExtra("id", myIdentityPatient);
		intent.putExtra("lastname", myLastNamePatient);
		intent.putExtra("firstname", myFirstNamePatient);
		intent.putExtra("dob", myDOBPatient);
		intent.putExtra("number", myNumberPatient);
		startActivity(intent);
	}
	
	public void sendMessageProvider(View view) {
		addListenerOnButtonProvider();
		Intent intent = new Intent(this, TabsActivity.class);
		intent.putExtra("id", myIdentityProvider);
		intent.putExtra("lastname", myLastNameProvider);
		intent.putExtra("firstname", myFirstNameProvider);
		intent.putExtra("dob", myDOBProvider);
		intent.putExtra("number", myNumberProvider);
		startActivity(intent);
	}
}
