package com.example.vethealth2;

import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageView;

public class MyQRActivity extends Activity {
	
	private String myEventType;
	private String myID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_qr);
		getData();
		Intent intent = getIntent();
		myEventType = intent.getStringExtra("eventtype");
		myID = intent.getStringExtra("id");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.my_qr, menu);
		return true;
	}
	
	public void getData() {
		Bitmap response=null;
		String[] parameters = new String[2];
		parameters[0]=myEventType;
		parameters[1]=myID;
		try {
			response = new RetreiveFeedTask().execute(parameters).get();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ExecutionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ImageView display = (ImageView) findViewById(R.id.myqrimageget);
		
		display.setImageBitmap(response);
		
	} 

}
