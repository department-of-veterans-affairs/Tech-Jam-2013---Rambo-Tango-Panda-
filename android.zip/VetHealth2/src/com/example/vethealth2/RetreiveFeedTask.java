package com.example.vethealth2;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

class RetreiveFeedTask extends AsyncTask<String, Void, Bitmap> {

    private Exception exception;
    private String myID, eventType;

    protected Bitmap doInBackground(String... urls) {
    	HttpResponse response = null;
    	Bitmap bm = null;
    	String eventtype = urls[0];
    	String myid = urls[1];
    	try {        
		        HttpClient client = new DefaultHttpClient();
		        HttpGet request = new HttpGet();
		        request.setURI(new URI("http://192.168.43.160:8080/qrcode/"+myid+"?eoctype="+eventtype));
		        response = client.execute(request);
				try {
					BufferedHttpEntity response2 = new BufferedHttpEntity(response.getEntity());
					bm = BitmapFactory.decodeStream(response2.getContent());
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    } catch (URISyntaxException e) {
		        e.printStackTrace();
		    } catch (ClientProtocolException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		    } catch (IOException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		    }
		return bm;
    }

    protected void onPostExecute(HttpResponse feed) {
        // TODO: check this.exception 
        // TODO: do something with the feed
    }
}